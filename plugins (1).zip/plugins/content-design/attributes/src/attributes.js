export default {
  content: {
    type: 'array',
    source: 'children',
    selector: 'h3'
  }
}
