export default <svg width="24px" height="24px" viewBox="" version="1.1">
  
</svg>
