export default {
  attributes: {
    titleWhite: 'Content design',
    titlePink: 'makes it clear',
    content: 'Our mission is to power prosperity around the world. For content designers, that means we simplify the complex world of tax and accounting and relay it in a familiar tone that builds confidence.',
    buttonText: 'Check the style guide',
    url: '/style-guide'
  }
}
