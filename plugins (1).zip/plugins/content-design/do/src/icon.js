// const el = wp.element.createElement;
export default <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg">
  <g id="do" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
    <g id="gray" transform="translate(2.000000, 1.000000)" fill="#D4D7DC" fill-rule="nonzero">
      <rect id="Rectangle" x="0" y="0" width="20" height="1"></rect>
      <rect id="Rectangle" x="0" y="2" width="20" height="1"></rect>
      <rect id="Rectangle" x="0" y="18" width="20" height="1"></rect>
      <rect id="Rectangle" x="0" y="20" width="20" height="1"></rect>
    </g>
    <g id="green" transform="translate(3.000000, 6.000000)">
      <rect id="Rectangle" fill="#2CA01C" fill-rule="nonzero" x="6" y="0" width="12" height="1"></rect>
      <rect id="Rectangle" fill="#2CA01C" fill-rule="nonzero" x="6" y="2" width="12" height="1"></rect>
      <rect id="Rectangle" fill="#2CA01C" fill-rule="nonzero" x="8" y="4" width="10" height="1"></rect>
      <rect id="Rectangle" fill="#2CA01C" fill-rule="nonzero" x="6" y="4" width="1" height="1"></rect>
      <rect id="Rectangle" fill="#2CA01C" fill-rule="nonzero" x="8" y="6" width="10" height="1"></rect>
      <rect id="Rectangle" fill="#2CA01C" fill-rule="nonzero" x="6" y="6" width="1" height="1"></rect>
      <rect id="Rectangle" fill="#2CA01C" fill-rule="nonzero" x="8" y="8" width="10" height="1"></rect>
      <rect id="Rectangle" fill="#2CA01C" fill-rule="nonzero" x="6" y="8" width="1" height="1"></rect>
      <rect id="Rectangle" fill="#2CA01C" fill-rule="nonzero" x="8" y="10" width="10" height="1"></rect>
      <rect id="Rectangle" fill="#2CA01C" fill-rule="nonzero" x="6" y="10" width="1" height="1"></rect>
      <circle id="Oval" stroke="#2CA01C" stroke-width="0.5" cx="2" cy="2" r="2.25"></circle>
      <path d="M1.75009858,3 C1.69652011,3 1.6161524,2.97260274 1.56257393,2.91780822 L1.0803677,2.42465753 C0.973210765,2.31506849 0.973210765,2.17808219 1.0803677,2.06849315 C1.13394617,2.01369863 1.18752464,1.98630137 1.26789235,1.98630137 C1.34826005,1.98630137 1.40183852,2.01369863 1.45541699,2.06849315 L1.72330934,2.36986301 L2.55377562,1.10958904 C2.60735409,1.02739726 2.68772179,1 2.7680895,1 C2.8484572,1 2.92882491,1.05479452 2.98240338,1.1369863 C3.00919261,1.21917808 3.00919261,1.30136986 2.95561414,1.38356164 L1.96441245,2.89041096 C1.91083398,2.94520548 1.83046628,3 1.75009858,3 L1.75009858,3 Z" id="Path" fill="#2CA01C" fill-rule="nonzero"></path>
    </g>
  </g>
</svg>
