export default {
    plural: {
      type: 'string',
      default: 'plural'
    }
}
