export default <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg">
  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
    <g transform="translate(-2.000000, -1.000000)">
      <g transform="translate(2.000000, 6.000000)" fill="#C9007A" fill-rule="nonzero">
        <rect x="10" y="1" width="12" height="1"></rect>
        <rect x="10" y="1" width="12" height="1"></rect>
        <rect x="10" y="1" width="12" height="1"></rect>
        <rect x="10" y="1" width="12" height="1"></rect>
        <rect x="10" y="1" width="12" height="1"></rect>
        <rect x="10" y="1" width="12" height="1"></rect>
        <rect x="10" y="1" width="12" height="1"></rect>
        <rect x="10" y="1" width="12" height="1"></rect>
        <rect x="10" y="1" width="12" height="1"></rect>
      </g>
    </g>
  </g>
</svg>
