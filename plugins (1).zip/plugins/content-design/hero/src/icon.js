export default <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg">
  <g id="hero" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
    <path d="M2,6 L2,18 L22,18 L22,6 L2,6 Z M20,16 L4,16 L4,8 L20,8 L20,16 Z" id="Shape" fill="#C9007A" fill-rule="nonzero"></path>
    <rect id="Rectangle" fill="#D4D7DC" fill-rule="nonzero" x="2" y="1" width="20" height="1"></rect>
    <rect id="Rectangle" fill="#D4D7DC" fill-rule="nonzero" x="2" y="3" width="20" height="1"></rect>
    <rect id="Rectangle" fill="#D4D7DC" fill-rule="nonzero" x="2" y="20" width="20" height="1"></rect>
    <rect id="Rectangle" fill="#D4D7DC" fill-rule="nonzero" x="2" y="22" width="20" height="1"></rect>
  </g>
</svg>
