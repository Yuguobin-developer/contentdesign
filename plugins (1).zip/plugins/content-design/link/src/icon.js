export default <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg">
  <g id="link" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
    <rect id="Rectangle" fill="#D4D7DC" fill-rule="nonzero" x="2" y="8" width="20" height="1"></rect>
    <rect id="Rectangle" fill="#D4D7DC" fill-rule="nonzero" x="2" y="6" width="20" height="1"></rect>
    <rect id="Rectangle" fill="#D4D7DC" fill-rule="nonzero" x="2" y="12" width="20" height="1"></rect>
    <rect id="Rectangle" fill="#D4D7DC" fill-rule="nonzero" x="2" y="14" width="20" height="1"></rect>
    <rect id="Rectangle" fill="#D4D7DC" fill-rule="nonzero" x="2" y="10" width="20" height="1"></rect>
    <rect id="Rectangle" fill="#C9007A" fill-rule="nonzero" x="2" y="17" width="5" height="1"></rect>
    <rect id="Rectangle-Copy" fill="#C9007A" fill-rule="nonzero" x="8" y="17" width="1" height="1"></rect>
  </g>
</svg>
