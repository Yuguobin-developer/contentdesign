const MiniHrEdit = () => {
  return <hr className={"mini-hr"}/>;
};

export default MiniHrEdit;
