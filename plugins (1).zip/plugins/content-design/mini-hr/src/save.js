const MiniHrSave = () => {
  return <hr className={"mini-hr"}/>;
};

export default MiniHrSave;
