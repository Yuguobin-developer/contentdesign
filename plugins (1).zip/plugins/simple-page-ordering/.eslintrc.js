module.exports = {
	env: { jquery: true },
	extends: ['@10up/eslint-config/wordpress'],
};
