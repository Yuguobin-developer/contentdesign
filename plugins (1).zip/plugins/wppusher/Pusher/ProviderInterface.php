<?php

namespace Pusher;

interface ProviderInterface
{
    public function register(Pusher $pusher);
}
