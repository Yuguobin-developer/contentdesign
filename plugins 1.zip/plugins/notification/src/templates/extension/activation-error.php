<?php
/**
 * Extension activation error notice
 *
 * @package notification
 */

?>

<div class="error">
	<p><?php $the( 'message' ); ?></p>
</div>
