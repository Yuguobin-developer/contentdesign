<?php
/**
 * Hidden field template
 *
 * @package notification
 */

echo $get( 'current_field' )->field(); // phpcs:ignore
