<?php
/**
 * No merge tags metabox template
 *
 * @package notification
 */

?>

<p><?php esc_html_e( 'No merge tags available for this trigger', 'notification' ); ?></p>
