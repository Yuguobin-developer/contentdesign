<?php
/**
 * No trigger metabox template
 *
 * @package notification
 */

?>

<p><?php esc_html_e( 'Please select trigger first', 'notification' ); ?></p>
