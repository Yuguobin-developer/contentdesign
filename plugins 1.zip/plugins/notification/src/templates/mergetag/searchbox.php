<?php
/**
 * Merge tag searchbox template
 *
 * @package notification
 */

?>

<input type="text" placeholder="<?php esc_attr_e( 'Search merge tags', 'notification' ); ?>" class="widefat notification-search-merge-tags" autocomplete="off" id="notification-search-merge-tags">
