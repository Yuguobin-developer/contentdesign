<?php
/**
 * Synchronization section template
 *
 * @package notification
 */

// Translators: Function name.
_e( sprintf( 'Synchronization is disabled. You can enable it with %s function', '<code>notification_sync()</code>' ) ); //phpcs:ignore
