export default {
  attributes: {
    content: 'Optimistic'
  },
  innerBlocks: [
    {
      name: 'core/paragraph',
      attributes: {
        content: '<b>Eat a good breakfast</b>'
      }
    },
    {
      name: 'core/paragraph',
      attributes: {
        content: 'Breakfast is known to be the most important meal of the day.'
      }
    },
    {
      name: 'core/list',
      attributes: {
        values: '<li>Eggs</li><li>Bacon</li><li>Fresh fruit</li><li>Coffee</li><li>Juice</li>'
      }
    }
  ]
}
