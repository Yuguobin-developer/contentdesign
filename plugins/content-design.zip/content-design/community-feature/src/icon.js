export default <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg">
  <g id="post" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
    <path d="M22,3 L22,11 L2,11 L2,3 L22,3 Z M21,4 L3,4 L3,10 L21,10 L21,4 Z" id="Combined-Shape" fill="#C9007A"></path>
    <rect id="Rectangle" fill="#C9007A" x="2" y="13" width="20" height="1"></rect>
    <rect id="Rectangle" fill="#C9007A" x="2" y="15" width="20" height="1"></rect>
    <rect id="Rectangle" fill="#C9007A" x="2" y="17" width="20" height="1"></rect>
    <rect id="Rectangle" fill="#C9007A" x="2" y="20" width="5" height="1"></rect>
    <rect id="Rectangle" fill="#C9007A" x="8" y="20" width="1" height="1"></rect>
  </g>
</svg>
