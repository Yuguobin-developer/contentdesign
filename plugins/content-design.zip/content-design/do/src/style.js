const img = {
  display: 'block',
  marginBottom: '10px'
};

const Style = {
  img
}

export default Style
