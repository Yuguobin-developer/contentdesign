export default {
  innerBlocks: [
    {
      name: 'core/paragraph',
      attributes: {
        content: '<b>Skip breakfast</b>',
      },
    },
    {
      name: 'core/paragraph',
      attributes: {
        content: 'If you miss breakfast, you\'ll feel tired the rest of the day.',
      },
    },
    {
      name: 'core/list',
      attributes: {
        values: '<li>Too busy</li><li>Late for work</li><li>Gotta run</li><li>No bananas</li><li>Slept in</li>',
      },
    },
  ],
}
