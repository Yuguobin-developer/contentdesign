// const el = wp.element.createElement;
export default <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg">
  <g id="dont" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
    <g id="gray" transform="translate(2.000000, 1.000000)" fill="#D4D7DC" fill-rule="nonzero">
      <rect id="Rectangle" x="0" y="0" width="20" height="1"></rect>
      <rect id="Rectangle" x="0" y="2" width="20" height="1"></rect>
      <rect id="Rectangle" x="0" y="18" width="20" height="1"></rect>
      <rect id="Rectangle" x="0" y="20" width="20" height="1"></rect>
    </g>
    <g id="red" transform="translate(3.000000, 6.000000)">
      <rect id="Rectangle" fill="#D52B1E" fill-rule="nonzero" x="6" y="0" width="12" height="1"></rect>
      <rect id="Rectangle" fill="#D52B1E" fill-rule="nonzero" x="6" y="2" width="12" height="1"></rect>
      <rect id="Rectangle" fill="#D52B1E" fill-rule="nonzero" x="8" y="4" width="10" height="1"></rect>
      <rect id="Rectangle" fill="#D52B1E" fill-rule="nonzero" x="6" y="4" width="1" height="1"></rect>
      <rect id="Rectangle" fill="#D52B1E" fill-rule="nonzero" x="8" y="6" width="10" height="1"></rect>
      <rect id="Rectangle" fill="#D52B1E" fill-rule="nonzero" x="6" y="6" width="1" height="1"></rect>
      <rect id="Rectangle" fill="#D52B1E" fill-rule="nonzero" x="8" y="8" width="10" height="1"></rect>
      <rect id="Rectangle" fill="#D52B1E" fill-rule="nonzero" x="6" y="8" width="1" height="1"></rect>
      <rect id="Rectangle" fill="#D52B1E" fill-rule="nonzero" x="8" y="10" width="10" height="1"></rect>
      <rect id="Rectangle" fill="#D52B1E" fill-rule="nonzero" x="6" y="10" width="1" height="1"></rect>
      <circle id="Oval" stroke="#D52B1E" stroke-width="0.5" cx="2" cy="2" r="2.25"></circle>
      <path d="M2.90604726,1.09395651 C2.78077693,0.968681165 2.57829395,0.968681165 2.45302363,1.09395651 L2,1.54699828 L1.54697637,1.09395651 C1.42170605,0.968681165 1.21890268,0.968681165 1.09395274,1.09395651 C0.968682419,1.21923185 0.968682419,1.42172294 1.09395274,1.54699828 L1.54697637,2.00004005 L1.09395274,2.45308182 C0.968682419,2.57835716 0.968682419,2.78116865 1.09395274,2.90612359 C1.15642771,2.96892146 1.23844614,3 1.32046456,3 C1.40248298,3 1.4845014,2.96892146 1.54697637,2.90612359 L2,2.45308182 L2.45302363,2.90612359 C2.5154986,2.96892146 2.59751702,3 2.67953544,3 C2.76155386,3 2.84357229,2.96892146 2.90604726,2.90612359 C3.03131758,2.78116865 3.03131758,2.57835716 2.90604726,2.45308182 L2.45302363,2.00004005 L2.90604726,1.54699828 C3.03131758,1.42172294 3.03131758,1.21923185 2.90604726,1.09395651 Z" id="Path" fill="#D52B1E" fill-rule="nonzero"></path>
    </g>
  </g>
</svg>
