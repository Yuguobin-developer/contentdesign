// const el = wp.element.createElement;
export default <svg width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg">
  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
    <g id="MINI-SEPARATOR" transform="translate(-2.000000, -1.000000)">
      <g id="Layer_1" transform="translate(2.000000, 1.000000)" fill="#D4D7DC" fill-rule="nonzero">
        <rect id="Rectangle" x="1" y="1" width="20" height="1"></rect>
      </g>
      <g id="Layer_1" transform="translate(2.000000, 5.000000)" fill="#D4D7DC" fill-rule="nonzero">
        <rect id="Rectangle" x="1" y="1" width="20" height="1"></rect>
      </g>
      <g id="Layer_1" transform="translate(2.000000, 7.000000)" fill="#D4D7DC" fill-rule="nonzero">
        <rect id="Rectangle" x="1" y="1" width="20" height="1"></rect>
      </g>
      <g id="Layer_1_copy" transform="translate(2.000000, 3.000000)" fill="#D4D7DC" fill-rule="nonzero">
        <rect id="Rectangle" x="1" y="1" width="20" height="1"></rect>
      </g>
      <g id="Layer_1" transform="translate(2.000000, 9.000000)" fill="#D4D7DC" fill-rule="nonzero">
        <rect id="Rectangle" x="1" y="1" width="20" height="1"></rect>
      </g>
      <g id="Layer_1" transform="translate(2.000000, 13.000000)" fill="#D4D7DC" fill-rule="nonzero">
        <rect id="Rectangle" x="1" y="1" width="20" height="1"></rect>
      </g>
      <g id="Layer_1_copy" transform="translate(2.000000, 11.000000)" fill="#C9007A" fill-rule="nonzero">
        <rect id="Rectangle" x="1" y="1" width="5" height="1"></rect>
      </g>
      <g id="Layer_1_copy_3" transform="translate(2.000000, 19.000000)" fill="#D4D7DC" fill-rule="nonzero">
        <rect id="Rectangle" x="1" y="1" width="20" height="1"></rect>
      </g>
      <g id="Layer_1_copy_2" transform="translate(2.000000, 21.000000)" fill="#D4D7DC" fill-rule="nonzero">
        <rect id="Rectangle" x="1" y="1" width="20" height="1"></rect>
      </g>
      <g id="Layer_1_copy_3" transform="translate(2.000000, 15.000000)" fill="#D4D7DC" fill-rule="nonzero">
        <rect id="Rectangle" x="1" y="1" width="20" height="1"></rect>
      </g>
      <g id="Layer_1_copy_2" transform="translate(2.000000, 17.000000)" fill="#D4D7DC" fill-rule="nonzero">
        <rect id="Rectangle" x="1" y="1" width="20" height="1"></rect>
      </g>
    </g>
  </g>
</svg>
