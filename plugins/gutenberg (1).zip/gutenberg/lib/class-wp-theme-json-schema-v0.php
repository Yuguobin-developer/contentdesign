<?php
/**
 * Class that implements a WP_Theme_JSON_Schema to convert
 * a given structure in v0 schema to the latest one.
 *
 * @package gutenberg
 */

/**
 * Class that implements a WP_Theme_JSON_Schema to convert
 * a given structure in v0 schema to the latest one.
 */