<?php
/**
 * Storable interface class
 *
 * @package notification
 */

namespace BracketSpace\Notification\Interfaces;

/**
 * Storable interface
 */
interface Storable extends \ArrayAccess, \Iterator {}
