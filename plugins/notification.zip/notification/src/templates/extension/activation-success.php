<?php
/**
 * Extension activation success notice
 *
 * @package notification
 */

?>

<div class="updated">
	<p><?php $the( 'message' ); ?></p>
</div>
