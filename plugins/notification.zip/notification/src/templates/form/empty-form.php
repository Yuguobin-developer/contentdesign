<?php
/**
 * Empty carrier form template
 *
 * @package notification
 */

?>

<p><?php esc_html_e( 'This Carrier has no fields.', 'notification' ); ?></p>
