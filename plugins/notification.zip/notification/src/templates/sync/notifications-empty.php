<?php
/**
 * Notifications template
 *
 * @package notification
 */

esc_html_e( 'All Notifications are synchronized and up to date.' );
