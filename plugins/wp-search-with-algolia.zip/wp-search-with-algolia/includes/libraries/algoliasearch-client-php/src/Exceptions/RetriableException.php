<?php

namespace Algolia\AlgoliaSearch\Exceptions;

final class RetriableException extends RequestException
{
}
