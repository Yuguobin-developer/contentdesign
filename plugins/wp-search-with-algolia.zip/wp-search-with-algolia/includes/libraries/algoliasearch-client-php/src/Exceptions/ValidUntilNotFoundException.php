<?php

namespace Algolia\AlgoliaSearch\Exceptions;

final class ValidUntilNotFoundException extends AlgoliaException
{
}
