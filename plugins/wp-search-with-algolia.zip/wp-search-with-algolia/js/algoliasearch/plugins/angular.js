'use strict';

// this file serves as a way to require the angularjs module
// in a commonJS way easily:
// require('algoliasearch/plugins/angular');
module.exports = require('../src/browser/builds/algoliasearch.angular.js');
