'use strict';

// this file serves as a way to easily require the jQuery module
// in a commonJS way:
// require('algoliasearch/plugins/jquery');
module.exports = require('../src/browser/builds/algoliasearch.jquery.js');
