'use strict';

// Alias for the react native build of the client.
module.exports = require('./src/reactnative/builds/algoliasearch.reactnative.js');
