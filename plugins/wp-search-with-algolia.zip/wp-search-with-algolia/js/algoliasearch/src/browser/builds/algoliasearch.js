'use strict';

var AlgoliaSearch = require('../../AlgoliaSearch.js');
var createAlgoliasearch = require('../createAlgoliasearch.js');

module.exports = createAlgoliasearch(AlgoliaSearch, 'Browser');
