'use strict';

module.exports = require('./src/standalone/');
