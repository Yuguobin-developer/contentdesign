'use strict';

module.exports = require('./src/angular/directive.js');
