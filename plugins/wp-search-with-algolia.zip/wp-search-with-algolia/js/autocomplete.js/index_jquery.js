'use strict';

module.exports = require('./src/jquery/plugin.js');
