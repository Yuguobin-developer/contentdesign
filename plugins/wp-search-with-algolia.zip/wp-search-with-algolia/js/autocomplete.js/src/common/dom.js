'use strict';

module.exports = {
  element: null
};
