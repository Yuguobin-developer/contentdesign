'use strict';

module.exports = {
  hits: require('./hits.js'),
  popularIn: require('./popularIn.js')
};
