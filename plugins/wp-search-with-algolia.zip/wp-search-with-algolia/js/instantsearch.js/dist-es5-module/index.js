'use strict';

var _main = require('./src/lib/main.js');

var _main2 = _interopRequireDefault(_main);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = _main2.default; // we need to export using commonjs for ease of usage in all
// JavaScript environments

/* eslint-disable import/no-commonjs */
