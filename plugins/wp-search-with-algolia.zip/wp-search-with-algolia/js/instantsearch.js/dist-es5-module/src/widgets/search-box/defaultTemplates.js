"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  poweredBy: "\n<div class=\"{{cssClasses.root}}\">\n  Search by\n  <a class=\"{{cssClasses.link}}\" href=\"{{url}}\" target=\"_blank\">Algolia</a>\n</div>"
};