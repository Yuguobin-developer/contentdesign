<?php
/**
 * WP Search With Algolia uninstall file.
 *
 * @author  WebDevStudios <contact@webdevstudios.com>
 * @since   1.0.0
 *
 * @package WebDevStudios\WPSWA
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	// If uninstall not called from WordPress, then exit.
	exit;
}
