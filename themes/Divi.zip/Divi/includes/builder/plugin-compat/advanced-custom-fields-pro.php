<?php
if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

/**
 * Load the same plugin compat class.
 */
require_once 'advanced-custom-fields.php';
