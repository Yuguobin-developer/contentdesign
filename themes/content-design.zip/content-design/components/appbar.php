<?php
?>
<header class="content-designtop-nav">
<a href="#" class="demo-menu material-icons mdc-top-app-bar__navigation-icon">menu</a>
<?php
  echo '<img style="height: 20px; width: auto;margin-left: -2px;" ';
  echo 'src="' . get_template_directory_uri() . '/public/assets/svgs/intuit.svg" />' ;
?>
<a href="#" class="material-icons mdc-top-app-bar__action-item" aria-label="Search" alt="Search">search</a>
</header>
