<div class="row image-text-part-one" style="background-color: <?php echo $com_background = get_field('com_background');?>" >
	<div class="col-12">		
		<div class="com-image-text" >
			<div class="text_wrap">
				<?php 
				echo $com_title = get_field('com_title'); 
				 echo $com_text = get_field('com_text'); ?>
			</div>
			<div class="img_wrap">
				<img src="<?php echo $com_image = get_field('com_image')['url'];?>">
			</div>
		</div>
	</div>
</div>

<style type="text/css">

	.page-template-template-community .image-text-part-one {
		width: 1380px;
	}

	.page-template-template-community .image-text-part-one .com-image-text .img_wrap img {
		position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
	}

	.page-template-template-community .image-text-part-one .com-image-text .img_wrap {
		width: 100%;
        height: 0;
        padding-bottom: 600px;
        position: relative;
	}

	@media (max-width: 1919px) and (min-width: 1440px) {		
		.page-template-template-community .image-text-part-one {
			width: 1306px;
		}
		.page-template-template-community .image-text-part-one .com-image-text .img_wrap {
			width: 100%;
	        height: 0;
	        padding-bottom: 550px;
	        position: relative;
		}
	}

	@media (max-width: 1439px) and (min-width: 1112px) {		
		.page-template-template-community .image-text-part-one {
			width: 1052px;
		}
		.page-template-template-community .image-text-part-one .com-image-text .img_wrap {
			width: 100%;
	        height: 0;
	        padding-bottom: 509px;
	        position: relative;
		}
	}

	@media (max-width: 1111px) and (min-width: 1024px) {		
		.page-template-template-community .image-text-part-one {
			width: 970px;
		}
		.page-template-template-community .image-text-part-one .com-image-text .img_wrap {
			width: 100%;
	        height: 0;
	        padding-bottom: 450px;
	        position: relative;
		}
	}

	@media (max-width: 1023px) and (min-width: 768px) {		
		.page-template-template-community .image-text-part-one {
			width: 728px;
		}
		.page-template-template-community .image-text-part-one .com-image-text .img_wrap {
			width: 100%;
	        height: 0;
	        padding-bottom: 400px;
	        position: relative;
		}
	}

	@media (max-width: 768px) {		
		.page-template-template-community .image-text-part-one {
			max-width: 728px;
			width: 100%;
		}
		.page-template-template-community .image-text-part-one .com-image-text .img_wrap {
			width: 100%;
	        height: 0;
	        padding-bottom: 350px;
	        position: relative;
		}
	}
	@media (max-width: 568px) {	
		.page-template-template-community .image-text-part-one .com-image-text .img_wrap {
			width: 100%;
	        height: 0;
	        padding-bottom: 300px;
	        position: relative;
		}
	}
	@media (min-width: 376px) and  (max-width: 568px){	
		.page-template-template-community .image-text-part-one .com-image-text .img_wrap {
			width: 100%;
	        height: 0;
	        padding-bottom: 250px;
	        position: relative;
		}
	}

	.page-template-template-community .image-text-part-one .com-image-text .text_wrap h1 {
		padding: 0px !important;
	} 
	.page-template-template-community .image-text-part-one .com-image-text .text_wrap h2 {
		padding: 0px !important;
	} 
	.page-template-template-community .image-text-part-one .com-image-text .text_wrap h3 {
		padding: 0px !important;
	} 
	.page-template-template-community .image-text-part-one .com-image-text .text_wrap h4 {
		padding: 0px !important;
	} 
	.page-template-template-community .image-text-part-one .com-image-text .text_wrap h5 {
		padding: 0px !important;
	} 
	.page-template-template-community .image-text-part-one .com-image-text .text_wrap {
		text-align: center;
	}
</style>