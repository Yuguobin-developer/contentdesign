<div class="row image-text-part-two">
	<div class="col-sm-6">		
		<div class="com-image-text-one com-image-text" >
			<div class="img_wrap">
				<img src="<?php echo $left_image = get_field('left_image')['url'];?>">
			</div>
			<div class="text_wrap">
				<?php echo $left_title = get_field('left_title'); ?>
				<?php echo $left_text = get_field('left_text'); ?>
			</div>
		</div>
	</div>
	<div class="col-sm-6">		
		<div class="com-image-text-two com-image-text" >
			<div class="img_wrap">
				<img src="<?php echo $right_image = get_field('right_image')['url'];?>">
			</div>
			<div class="text_wrap">
				<?php echo $left_title = get_field('right_title'); ?>
				<?php echo $left_text = get_field('right_text'); ?>
			</div>
		</div>
	</div>
</div>
<style type="text/css">

	.page-template-template-community .image-text-part-two {
		width: 1380px;
	}
	.page-template-template-community .image-text-part-two .com-image-text {
		width: 675px;
	}
	.page-template-template-community .image-text-part-two .com-image-text .img_wrap {
		width: 100%;
        height: 0;
        padding-bottom: 472px;
        position: relative;
	}
	.page-template-template-community .image-text-part-two .com-image-text .text_wrap {
		padding: 50px;
	} 
	.page-template-template-community .image-text-part-two .com-image-text .img_wrap img {
		position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
	}

	@media (max-width: 1919px) and (min-width: 1440px) {		
		.page-template-template-community .image-text-part-two {
			width: 1306px;
		}
		.page-template-template-community .image-text-part-two .com-image-text {
			width: 638px;
		}
		.page-template-template-community .image-text-part-two .com-image-text .img_wrap {
			width: 100%;
	        height: 0;
	        padding-bottom: 446px;
	        position: relative;
		}
		.page-template-template-community .image-text-part-two .com-image-text .text_wrap {
			padding: 40px;
		} 
	}

	@media (max-width: 1439px) and (min-width: 1112px) {		
		.page-template-template-community .image-text-part-two {
			width: 1052px;
		}
		.page-template-template-community .image-text-part-two .com-image-text {
			width: 511px;
		}
		.page-template-template-community .image-text-part-two .com-image-text .img_wrap {
			width: 100%;
	        height: 0;
	        padding-bottom: 357px;
	        position: relative;
		}
		.page-template-template-community .image-text-part-two .com-image-text .text_wrap {
			padding: 40px;
		} 
	}

	@media (max-width: 1111px) and (min-width: 1024px) {		
		.page-template-template-community .image-text-part-two {
			width: 970px;
		}
		.page-template-template-community .image-text-part-two .com-image-text {
			width: 470px;
		}
		.page-template-template-community .image-text-part-two .com-image-text .img_wrap {
			width: 100%;
	        height: 0;
	        padding-bottom: 328px;
	        position: relative;
		}
		.page-template-template-community .image-text-part-two .com-image-text .text_wrap {
			padding: 40px;
		} 
	}

	@media (max-width: 1023px) and (min-width: 768px) {		
		.page-template-template-community .image-text-part-two {
			width: 728px;
		}
		.page-template-template-community .image-text-part-two .com-image-text {
			width: 354px;
		}
		.page-template-template-community .image-text-part-two .com-image-text .img_wrap {
			width: 100%;
	        height: 0;
	        padding-bottom: 247px;
	        position: relative;
		}
		.page-template-template-community .image-text-part-two .com-image-text .text_wrap {
			padding: 30px;
			padding-top: 40px;
		} 
	}

	@media (max-width: 768px) {		
		.page-template-template-community .image-text-part-two {
			max-width: 728px;
			width: 100%;
		}
		.page-template-template-community .image-text-part-two .com-image-text {
			max-width: 728px;
			width: 100%;
		}
		.page-template-template-community .image-text-part-two .com-image-text .img_wrap {
			width: 100%;
	        height: 0;
	        padding-bottom: 247px;
	        position: relative;
		}
		.page-template-template-community .image-text-part-two .com-image-text .text_wrap {
			padding: 30px;
			padding-top: 40px;
		} 
	}

	.page-template-template-community .image-text-part-two .com-image-text .text_wrap h1 {
		padding: 0px !important;
	} 
	.page-template-template-community .image-text-part-two .com-image-text .text_wrap h2 {
		padding: 0px !important;
	} 
	.page-template-template-community .image-text-part-two .com-image-text .text_wrap h3 {
		padding: 0px !important;
	} 
	.page-template-template-community .image-text-part-two .com-image-text .text_wrap h4 {
		padding: 0px !important;
	} 
	.page-template-template-community .image-text-part-two .com-image-text .text_wrap h5 {
		padding: 0px !important;
	} 
</style>