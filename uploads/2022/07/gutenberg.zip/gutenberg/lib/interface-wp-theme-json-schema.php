<?php
/**
 * Schema interface for theme.json structures.
 *
 * @package gutenberg
 */

/**
 * Schema interface for theme.json structures.
 *
 * @package gutenberg
 */

