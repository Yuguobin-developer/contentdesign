<?php
/**
 * WPSEO Premium plugin file.
 *
 * @package WPSEO\Premium\Classes
 */

/**
 * Class WPSEO_Redirect_Import_Exception
 */
class WPSEO_Redirect_Import_Exception extends Exception {

}
