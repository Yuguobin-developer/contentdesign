<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/job-location-address" only-nested=true}}
{{html name="address"}}
