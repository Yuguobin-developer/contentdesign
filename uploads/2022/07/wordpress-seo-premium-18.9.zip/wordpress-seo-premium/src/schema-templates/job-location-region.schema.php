<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/job-location-region" only-nested=true}}
{{html name="region"}}
